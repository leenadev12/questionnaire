import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';

import { question } from '../../_models/question.model';
import { QuestionService } from '../../_services/question.service';
import { AnswerService } from '../../_services/answer.service';
import { FormArray, Validators } from '@angular/forms';

@Component({
  selector: 'app-answer-question',
  templateUrl: './answer-question.component.html',
  styleUrls: ['./answer-question.component.scss'],
})
export class AnswerQuestionComponent implements OnInit {
  questionList: question[] = [];

  answeredQuestionSubscription: Subscription = new Subscription();

  unAnsweredQuestionSubscription: Subscription = new Subscription();

  AnsweredQuestionList: question[] = [];

  unAnsweredQuestionList: question[] = [];

  changedQuestion: Subscription = new Subscription();

  optionsquestionOptions = new FormArray([]);

  constructor(
    private questionService: QuestionService,
    private answerService: AnswerService
  ) {}

  ngOnInit(): void {
    this.answerService.filterQuestion();
    this.questionList = this.questionService.getQuestionList();
    this.changedQuestion = this.questionService.changedQuestions.subscribe(
      (questions: question[]) => {
        this.questionList = questions;
      }
    );
    this.answeredQuestionSubscription = this.answerService.answeredQuestion.subscribe((questions: question[]) => {
      this.AnsweredQuestionList = questions;
    })
    this.unAnsweredQuestionSubscription = this.answerService.unAnsweredQuestion.subscribe((questions: question[]) => {
      this.unAnsweredQuestionList = questions;
    })
    this.initForm();
  }

  initForm() {}
}

import { Pipe, PipeTransform } from '@angular/core';
import { question } from '../_models/question.model';

@Pipe({
  name: 'sortByTime',
})
export class SortByTimePipe implements PipeTransform {
  transform(questionData: question[]) {
    return questionData.sort(
      (a, b) =>
        new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime()
    );
  }
}

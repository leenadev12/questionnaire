export interface questionTypes {
  type: 'open' | 'singleSelect' | 'multiSelect';
}
